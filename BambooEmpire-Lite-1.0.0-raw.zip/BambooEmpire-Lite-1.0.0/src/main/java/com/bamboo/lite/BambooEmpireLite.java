package com.bamboo.lite;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.UUID;

public final class BambooEmpireLite extends JavaPlugin implements Listener {
    private static final String PREFIX = ChatColor.GREEN + "[BambooEmpire] " + ChatColor.GRAY;
    private File dataFile;
    private YamlConfiguration data;
    private NamespacedKey shopPriceKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "balances.yml");
        if (!dataFile.exists()) {
            try {
                getDataFolder().mkdirs();
                dataFile.createNewFile();
            } catch (IOException e) {
                getLogger().severe("Не удалось создать balances.yml: " + e.getMessage());
            }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
        shopPriceKey = new NamespacedKey(this, "lite_shop_price");
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("BambooEmpire Lite " + getDescription().getVersion() + " включён для Paper 1.21.11");
    }

    @Override
    public void onDisable() { saveBalances(); }

    private String path(UUID uuid) { return "balances." + uuid; }
    private double balance(UUID uuid) { return data.getDouble(path(uuid), 0.0); }
    private void setBalance(UUID uuid, double amount) { data.set(path(uuid), Math.max(0, round(amount))); }
    private double round(double value) { return Math.round(value * 100.0) / 100.0; }
    private void saveBalances() {
        if (data == null || dataFile == null) return;
        try { data.save(dataFile); }
        catch (IOException e) { getLogger().severe("Не удалось сохранить баланс: " + e.getMessage()); }
    }
    private String money(double amount) { return String.format(Locale.US, "%.2f", amount).replaceAll("\\.00$", ""); }
    private void msg(CommandSender sender, String text) { sender.sendMessage(PREFIX + text); }
    private Player findOnline(String name) { return Bukkit.getPlayerExact(name); }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "bamboo" -> {
                if (args.length > 0 && sender.hasPermission("bamboo.admin")) {
                    Player target = findOnline(args[0]);
                    if (target == null) { msg(sender, "Игрок должен быть в сети."); return true; }
                    msg(sender, "Баланс " + target.getName() + ": " + money(balance(target.getUniqueId())) + " ЧБ.");
                    return true;
                }
                if (!(sender instanceof Player player)) { msg(sender, "Из консоли укажи игрока: /bamboo <ник>."); return true; }
                msg(sender, "Твой баланс: " + money(balance(player.getUniqueId())) + " ЧБ.");
                return true;
            }
            case "sell" -> {
                if (!(sender instanceof Player player)) { msg(sender, "Команда доступна только игроку."); return true; }
                int amount = 0;
                for (ItemStack item : player.getInventory().getStorageContents()) {
                    if (item != null && item.getType() == Material.BAMBOO) amount += item.getAmount();
                }
                if (amount <= 0) { msg(player, "У тебя нет бамбука для продажи."); return true; }
                int tier = Math.max(1, Math.min(10, (int) Math.ceil(amount / 64.0)));
                double multiplier = 1.0 + tier * getConfig().getDouble("sell.tier-multiplier-step", 0.1);
                double price = amount * getConfig().getDouble("sell.base-price", 1.0) * multiplier;
                int left = amount;
                for (int slot = 0; slot < player.getInventory().getStorageContents().length; slot++) {
                    ItemStack item = player.getInventory().getItem(slot);
                    if (item == null || item.getType() != Material.BAMBOO) continue;
                    int remove = Math.min(left, item.getAmount());
                    item.setAmount(item.getAmount() - remove);
                    if (item.getAmount() <= 0) player.getInventory().setItem(slot, null);
                    left -= remove;
                    if (left <= 0) break;
                }
                setBalance(player.getUniqueId(), balance(player.getUniqueId()) + price);
                saveBalances();
                msg(player, "Продано " + amount + " бамбука за " + money(price) + " ЧБ (множитель T" + tier + ").");
                return true;
            }
            case "bamboopay" -> {
                if (!(sender instanceof Player player)) { msg(sender, "Команда доступна только игроку."); return true; }
                if (args.length != 2) { msg(player, "Использование: /bamboopay <игрок> <сумма>."); return true; }
                Player target = findOnline(args[0]);
                if (target == null) { msg(player, "Игрок должен быть в сети."); return true; }
                if (target.getUniqueId().equals(player.getUniqueId())) { msg(player, "Нельзя перевести ЧБ самому себе."); return true; }
                double amount;
                try { amount = Double.parseDouble(args[1]); }
                catch (NumberFormatException e) { msg(player, "Сумма должна быть числом."); return true; }
                if (!Double.isFinite(amount) || amount <= 0 || amount != round(amount)) { msg(player, "Укажи положительную сумму до двух знаков после запятой."); return true; }
                if (balance(player.getUniqueId()) < amount) { msg(player, "Недостаточно ЧБ."); return true; }
                setBalance(player.getUniqueId(), balance(player.getUniqueId()) - amount);
                setBalance(target.getUniqueId(), balance(target.getUniqueId()) + amount);
                saveBalances();
                msg(player, "Ты перевёл " + money(amount) + " ЧБ игроку " + target.getName() + ".");
                msg(target, player.getName() + " перевёл тебе " + money(amount) + " ЧБ.");
                return true;
            }
            case "shop" -> {
                if (!(sender instanceof Player player)) { msg(sender, "Магазин доступен только игроку."); return true; }
                openShop(player);
                return true;
            }
            case "tier" -> {
                if (!(sender instanceof Player player)) { msg(sender, "Команда доступна только игроку."); return true; }
                int bamboo = 0;
                for (ItemStack item : player.getInventory().getStorageContents()) if (item != null && item.getType() == Material.BAMBOO) bamboo += item.getAmount();
                int tier = Math.max(1, Math.min(10, (int) Math.ceil(bamboo / 64.0)));
                msg(player, "По количеству бамбука в инвентаре: T" + tier + " (" + bamboo + " бамбука). Продажа использует этот множитель.");
                return true;
            }
            case "bambooadmin" -> {
                if (!sender.hasPermission("bamboo.admin")) { msg(sender, "Недостаточно прав."); return true; }
                if (args.length == 0) { msg(sender, "Использование: /bambooadmin <give|set|wipe> <ник|all> [сумма]."); return true; }
                switch (args[0].toLowerCase(Locale.ROOT)) {
                    case "give", "set" -> {
                        if (args.length != 3) { msg(sender, "Использование: /bambooadmin " + args[0] + " <ник> <сумма>."); return true; }
                        Player target = findOnline(args[1]);
                        if (target == null) { msg(sender, "Игрок должен быть в сети."); return true; }
                        double amount;
                        try { amount = Double.parseDouble(args[2]); }
                        catch (NumberFormatException e) { msg(sender, "Сумма должна быть числом."); return true; }
                        if (!Double.isFinite(amount) || amount < 0) { msg(sender, "Сумма не может быть отрицательной."); return true; }
                        if (args[0].equalsIgnoreCase("give")) setBalance(target.getUniqueId(), balance(target.getUniqueId()) + amount);
                        else setBalance(target.getUniqueId(), amount);
                        saveBalances();
                        msg(sender, "Готово. Баланс " + target.getName() + ": " + money(balance(target.getUniqueId())) + " ЧБ.");
                        return true;
                    }
                    case "wipe" -> {
                        if (args.length != 1 || !sender.isOp()) { msg(sender, "Только OP: /bambooadmin wipe."); return true; }
                        data.set("balances", null);
                        saveBalances();
                        msg(sender, "Все балансы обнулены.");
                        return true;
                    }
                    default -> { msg(sender, "Команды: give, set, wipe."); return true; }
                }
            }
            case "help" -> {
                msg(sender, "Команды: /bamboo, /sell, /bamboopay, /shop, /tier, /help.");
                if (sender.hasPermission("bamboo.admin")) msg(sender, "Админ: /bambooadmin give|set|wipe.");
                return true;
            }
            default -> { return false; }
        }
    }

    private void openShop(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, ChatColor.DARK_GREEN + "Bamboo Empire | Магазин");
        addShopItem(inv, 11, Material.IRON_INGOT, "Железный слиток", getConfig().getDouble("shop.items.iron_ingot", 25));
        addShopItem(inv, 13, Material.GOLD_INGOT, "Золотой слиток", getConfig().getDouble("shop.items.gold_ingot", 50));
        addShopItem(inv, 15, Material.EMERALD, "Изумруд", getConfig().getDouble("shop.items.emerald", 100));
        player.openInventory(inv);
    }

    private void addShopItem(Inventory inv, int slot, Material material, String name, double price) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GREEN + name);
        meta.setLore(java.util.List.of(ChatColor.GRAY + "Цена: " + money(price) + " ЧБ", ChatColor.YELLOW + "Нажми, чтобы купить 1 шт."));
        meta.getPersistentDataContainer().set(shopPriceKey, PersistentDataType.DOUBLE, price);
        item.setItemMeta(meta);
        inv.setItem(slot, item);
    }

    @EventHandler
    public void onShopClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!ChatColor.stripColor(event.getView().getTitle()).equals("Bamboo Empire | Магазин")) return;
        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        Double price = clicked.getItemMeta().getPersistentDataContainer().get(shopPriceKey, PersistentDataType.DOUBLE);
        if (price == null) return;
        if (balance(player.getUniqueId()) < price) { msg(player, "Недостаточно ЧБ. Нужно " + money(price) + "."); return; }
        if (player.getInventory().firstEmpty() == -1) { msg(player, "Освободи слот в инвентаре."); return; }
        setBalance(player.getUniqueId(), balance(player.getUniqueId()) - price);
        player.getInventory().addItem(new ItemStack(clicked.getType(), 1));
        saveBalances();
        msg(player, "Куплено: " + ChatColor.stripColor(clicked.getItemMeta().getDisplayName()) + " за " + money(price) + " ЧБ.");
    }
}
